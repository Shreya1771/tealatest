var Colors = {
  MAIN_THEME_COLOR : '#FBC132'
};

export default Colors;

const config = {
  API_KEY : process.env.API_KEY || "key_4fc9700607a0479e874a74c07898ca38",
  API_TOKEN : process.env.API_TOKEN || "tok_cff8cb2fbdf04ec5a7a5e64b90932fa8",
  USERID : process.env.USERID || "usr_69937e36f9a144609445a32a431f9d79",
  DEMO_EMAIL : "tea@demo.com",
  DEMO_PASSWORD : "demo123"
};

module.exports = config;
